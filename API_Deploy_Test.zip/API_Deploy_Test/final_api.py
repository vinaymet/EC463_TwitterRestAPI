from flask import Flask
from flask import request

app = Flask(__name__)

@app.route("/twitter",methods=['POST'])
def welcome():
    if request.method == 'POST':

        # -- Twitter --

        USER_INPUT = request.json
        USER_INPUT = USER_INPUT['username']

        import tweepy
        import pandas as pd
        import os
        from google.cloud import language_v1
        import botometer

        # Twitter API Keys

        twitter_API_key = '6RLUh7BzRCdwfdCyIFw5cOCHj'
        twitter_API_secret = '736rrQnMbO06Ck0YBCHcfXZPqgPRjU6CSoYOkW6e3clW7JbiBm'
        bearer_token = 'AAAAAAAAAAAAAAAAAAAAABksfwEAAAAAoarqqrrSJe0as2Pq6Hkbw3IqyZY%3DDI0s4m7F13gBUxe59ZKnJbWs5HNqhNkIGRKlIPdndufgA21adN'
        twitter_API_access = '1557118965314453504-7adMRXYRUR7nQEWHEQ8Mw97GbhfFqX'
        twitter_API_token_secret = '2Yn27VOQ6VntnXchseqbJtWlxGz3XKN0O2guw564Zn0At'

        # Set up Tweepy Authentication

        auth = tweepy.OAuthHandler(twitter_API_key,twitter_API_secret)
        auth.set_access_token(twitter_API_access,twitter_API_token_secret)

        api = tweepy.API(auth)

        # Verify Valid Tweepy Authentication

        try:
            api.verify_credentials()
            print('Successful Authentication')
        except:
            print('Failed authentication')

        # If sucessful, try and pull latest tweet from sample user

        try:
            tweets = api.user_timeline(screen_name=USER_INPUT,
                                       # 200 is the maximum allowed count
                                       count=200,
                                       include_rts = False,
                                       # Necessary to keep full_text
                                       # otherwise only the first 140 words are extracted
                                       tweet_mode = 'extended'
                                       )
        except tweepy.error.TweepError:
            output_dict = {
                "Sentiment" : "NOT A VALID ACCOUNT",
                "Major_Categories" : "NOT A VALID ACCOUNT",
                "BotScore" : "NOT A VALID ACCOUNT"
            }
            return output_dict


        tweetString = ""

        for info in tweets:
            tweetString = tweetString + " " + str(info.full_text)

        # ---Google API---

        os.environ["GOOGLE_APPLICATION_CREDENTIALS"] =r"cloud.json"

        client = language_v1.LanguageServiceClient()

        def getSentiment(text):
            document = language_v1.Document(content=text, type=language_v1.Document.Type.PLAIN_TEXT)
            sentiment = client.analyze_sentiment(request={"document": document}).document_sentiment
            return sentiment.score

        def getCategories(text):
            document = language_v1.Document(content=text, type=language_v1.Document.Type.PLAIN_TEXT)
            response = client.classify_text(request = {'document': document})
            category_names = ""
            for category in response.categories:
                category_names = category_names + str(category.name) + " "
            return category_names

        # ---Botometer---

        twitter_app_auth = {
                            'consumer_key': '6RLUh7BzRCdwfdCyIFw5cOCHj',
                            'consumer_secret': '736rrQnMbO06Ck0YBCHcfXZPqgPRjU6CSoYOkW6e3clW7JbiBm',
                            'access_token': '1557118965314453504-7adMRXYRUR7nQEWHEQ8Mw97GbhfFqX',
                            'access_token_secret': '2Yn27VOQ6VntnXchseqbJtWlxGz3XKN0O2guw564Zn0At'
                           }

        bom = botometer.Botometer(wait_on_ratelimit=True,
                                  rapidapi_key='4d3863afb7msh188df29dde30c0ep1c9cf6jsn95f19cdfb25c',
                                  botometer_api_url='https://botometer-pro.p.rapidapi.com',
                                  **twitter_app_auth)

        try:
            result = bom.check_account(USER_INPUT)
            botscore = result['display_scores']['english']['overall']
            output_dict = {
                "Sentiment" : str(getSentiment(tweetString)),
                "Major_Categories" : str(getCategories(tweetString)),
                "BotScore" : botscore
            }
        except botometer.NoTimelineError:
            output_dict = {
                "Sentiment" : "NOT A VALID ACCOUNT",
                "Major_Categories" : "NOT A VALID ACCOUNT",
                "BotScore" : "NOT A VALID ACCOUNT"
            }


        return output_dict

if(__name__=="__main__"):
    app.run()
